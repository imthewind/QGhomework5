#ifndef __LQUEUE_H__
#define __LQUEUE_H__

#include "Input.h"
#include "binary_sort_tree.h"

#define Max 100

typedef struct {      //���д洢���ڵ� 
	int front, rear;
	Node* data[Max];
} Queue;

#endif // !__LQUEUE_H__
