#ifndef __MENU_H__
#define __MENU_H__

#include "Input.h"
#include <Windows.h>

void menu();

#endif // !__MENU_H__
