#include "binary_sort_tree.h"
#include "Input.h"
#include "LQueue.h"
#include "SqStack.h"

Status BST_init(BinarySortTreePtr t)
{
	t->root = NULL;//�ÿ�
	if (!t)
		return failed;
	return succeed;
}

Status BST_destory(BinarySortTreePtr t)
{
	free(t->root);
	t->root = NULL;
	if (t->root != NULL)
		return failed;
	return succeed;
}

Status BST_insert(BinarySortTreePtr t, ElemType e)
{
	Node* new_node = (Node*)malloc(sizeof(Node));//�������ڴ�
	if (!new_node)
		return false;
	new_node->value = e;
	new_node->left = NULL;
	new_node->right = NULL;
	NodePtr p = t->root;
	if (!BST_search(t, e))//û�иýڵ�
	{
		if (t->root == NULL)
			t->root = new_node;
		else
		{
			while (p->left != NULL || p->right != NULL)//���������һ���ڵ�
			{
				if (p->value > e)
				{
					if (p->left != NULL)
						p = p->left;
					else
						break;
				}
				else if (p->value < e)
				{
					if (p->right != NULL)
						p = p->right;
					else
						break;
				}
			}
			if (p->value > e)
				p->left = new_node;
			else if (p->value < e)
				p->right = new_node;
		}
	}
	else
	{
		printf("�����Ѿ����ڸýڵ��ˣ�\n");
		return failed;
	}
	return succeed;
}

Status BST_delete(BinarySortTreePtr t, ElemType* e)
{
	if (t->root == NULL)
	{
		printf("������\n");
		return failed;
	}
	NodePtr p = t->root;
	Node* parent = NULL;
	Node* get_node = NULL;
	if (BST_search(t, *e))
	{
		while (p->left != NULL || p->right != NULL)
		{
			parent = p;
			if (p->value > *e)
			{
				if (p->left != NULL)
					p = p->left;
				else
					break;
			}
			else if (p->value < *e)
			{
				if (p->right != NULL)
					p = p->right;
				else
					break;
			}
			else if (p->value == *e)
			{
				get_node = p;
				break;
			}
		}
		if (p->value == *e)
			get_node = p;
		if (get_node != NULL)
		{
			Node* q = NULL, * s = NULL;
			if (get_node->left != NULL && get_node->right == NULL)
			{
				q = p->left;
				p->value = q->value;
				p->left = q->left;
				p->right = q->right;
				free(q);
			}
			else if (get_node->left == NULL && get_node->right != NULL)
			{
				q = p->right;
				p->value = q->value;
				p->left = q->left;
				p->right = q->right;
				free(q);
			}
			else if(get_node->left != NULL && get_node->right != NULL)
			{
				q = p;
				s = q->left;
				while (s->right != NULL)
				{
					q = s;//��¼��һλ��
					s = q->right;
				}
				p->value = s->value;
				if (q != p)
					q->right = s->left;
				else
					q->left = s->left;
				free(s);
			}
			else if (get_node->left == NULL && get_node->right == NULL)
			{
				if (parent == t->root)
				{
					free(parent);
					t->root = NULL;
				}
				else
				{
					if (parent->left == get_node)
						parent->left = NULL;
					else if (parent->right == get_node)
						parent->right = NULL;
					free(get_node);
				}
			}
		}
	}
	else
	{
		printf("�޸ýڵ㣡\n");
		return failed;
	}
	return succeed;
}

Status BST_search(BinarySortTreePtr t, ElemType e)
{
	if (t->root == NULL)
		return failed;
	NodePtr p = t->root;
	while (p->left != NULL || p->right != NULL)
	{
		if (p->value > e)
		{
			if (p->left != NULL)
				p = p->left;
			else
				break;
		}
		else if (p->value < e)
		{
			if (p->right != NULL)
				p = p->right;
			else
				break;
		}
		else if (p->value == e)
			return succeed;
	}
	if (p->value == e)
		return succeed;
	return failed;
}

Status BST_preorderI(BinarySortTreePtr t, void (*visit)(NodePtr data))
{
	Node* p = t->root, * s = (Node*)malloc(sizeof(Node));
	if (p == NULL)
	{
		printf("������\n");
		return failed;
	}
	SqStack* q = (SqStack*)malloc(sizeof(SqStack));
	if (!initStack(q, Max))
		return failed;
	if (!pushStack(q, *p))
		return failed;
	int n = 0;
	while (1)
	{
		n++;
		if (n >1)
			visit(s);
		if (!popStack(q, s))
			break;
		if (s->right != NULL)
			pushStack(q, *(s->right));
		if (s->left != NULL)
			pushStack(q, *(s->left));
	}
	free(q);
	q = NULL;
	free(s);
	s = NULL;
	return succeed;
}

void PreOrderTraverse(Node* p, void (*visit)(NodePtr data))
{
	if (p == NULL)
		return;
	visit(p);
	PreOrderTraverse(p->left, visit);
	PreOrderTraverse(p->right, visit);
}

Status BST_preorderR(BinarySortTreePtr t, void (*visit)(NodePtr data))
{
	PreOrderTraverse(t->root, visit);
}

Status BST_inorderI(BinarySortTreePtr t, void (*visit)(NodePtr data))
{
	Node* p = t->root, * s = (Node*)malloc(sizeof(Node));
	if (p == NULL)
	{
		printf("������\n");
		return failed;
	}
	SqStack* q = (SqStack*)malloc(sizeof(SqStack));
	if (!initStack(q, Max))
		return failed;
	while (1)
	{
		if (p != NULL)
		{
			pushStack(q, *p);
			p = p->left;
		}
		else
		{
			if (!popStack(q, s))
				break;
			visit(s);
			p = s->right;
		}
	}
	free(q);
	q = NULL;
	free(s);
	s = NULL;
	return succeed;
}

void InOrderTraverse(Node* p, void (*visit)(NodePtr data))
{
	if (p == NULL)
		return;
	InOrderTraverse(p->left, visit);
	visit(p);
	InOrderTraverse(p->right, visit);
}

Status BST_inorderR(BinarySortTreePtr t, void (*visit)(NodePtr data))
{
	InOrderTraverse(t->root, visit);
}

Status BST_postorderI(BinarySortTreePtr t, void (*visit)(NodePtr data))
{
	Node* p = t->root;
	if (p == NULL)
	{
		printf("������\n");
		return failed;
	}
	Node* s1[50];   //������
	int s2[50];     //S2�������״̬��־����tag    0 ������ݲ��ܷ���  1 �� �����Ա�����
	int top = 0;
	int is_empty_stack;
	do
	{
		while (p != NULL)
		{
			s1[++top] = p;   //��ջ
			s2[top] = 0;
			p = p->left;
			is_empty_stack = 0;  //ջ����
		}
		if (top == 0)
			is_empty_stack = 1;
		else if (s2[top] == 0)
		{
			p = s1[top]->right;
			s2[top] = 1;
		}
		else
		{
			p = s1[top];            //��ջ
			top--;
			visit(p);
			p = NULL;
		}
	} while (!is_empty_stack);
	return succeed;
}

void PostOrderTraverse(Node* p, void (*visit)(NodePtr data))
{
	if (p == NULL)
		return;
	PostOrderTraverse(p->left, visit);
	PostOrderTraverse(p->right, visit);
	visit(p);
}

Status BST_postorderR(BinarySortTreePtr t, void (*visit)(NodePtr data))
{
	PostOrderTraverse(t->root, visit);
}

Status BST_levelOrder(BinarySortTreePtr t, void (*visit)(NodePtr data))
{
	Node* p = t->root;
	if (p == NULL)
	{
		printf("������\n");
		return failed;
	}
	Queue* q = (Queue*)malloc(sizeof(Queue));
	initQueue(q);
	InQueue(q, p);
	while (!EmptyQueue(q))
	{
		p = DeQueue(q);
		visit(p);
		if (p->left != NULL)
			InQueue(q, p->left);
		if (p->right != NULL)
			InQueue(q, p->right);
	}
	return succeed;
}